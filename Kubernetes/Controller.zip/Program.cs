﻿namespace Kubernetes
{
    public static class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}