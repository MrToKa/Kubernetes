using System;
using System.Collections.Generic;
using System.Linq;

namespace Kubernetes
{
    public class Controller : IController
    {
        public Dictionary<string, Pod> pods = new Dictionary<string, Pod>();
        public SortedDictionary<(int Port, string Namespace), Pod> sortedPods = new SortedDictionary<(int Port, string Namespace), Pod>();

        //This method checks whether a pod with a specific ID exists in the system. It returns true if a pod with the given ID is present, and false otherwise.
        public bool Contains(string podId)
        {
            return pods.ContainsKey(podId);
        }

        //This method is used to add a pod for deployment. It takes a Pod object as an argument and adds it to the system for execution. 
        private Dictionary<int, List<Pod>> podsByPort = new Dictionary<int, List<Pod>>();
        private Dictionary<string, List<Pod>> podsByNamespace = new Dictionary<string, List<Pod>>();

        public void Deploy(Pod pod)
        {
            pods.Add(pod.Id, pod);
            sortedPods.Add((pod.Port, pod.Namespace), pod);

            if (!podsByPort.ContainsKey(pod.Port))
            {
                podsByPort[pod.Port] = new List<Pod>();
            }
            podsByPort[pod.Port].Add(pod);

            if (!podsByNamespace.ContainsKey(pod.Namespace))
            {
                podsByNamespace[pod.Namespace] = new List<Pod>();
            }
            podsByNamespace[pod.Namespace].Add(pod);
        }

        public IEnumerable<Pod> GetPodsBetweenPort(int lowerBound, int upperBound)
        {
            return podsByPort.Where(kvp => kvp.Key >= lowerBound && kvp.Key <= upperBound).SelectMany(kvp => kvp.Value);
        }

        public IEnumerable<Pod> GetPodsInNamespace(string @namespace)
        {
            return podsByNamespace.ContainsKey(@namespace) ? podsByNamespace[@namespace] : Enumerable.Empty<Pod>();
        }


        //This method retrieves a specific pod from the system based on its ID. If a pod with the provided ID exists, it returns the corresponding Pod object. If no such pod exists, it throws an ArgumentException.
        public Pod GetPod(string podId)
        {
            if (!pods.ContainsKey(podId))
            {
                throw new ArgumentException();
            }
            return pods[podId];
        }




        //This method returns an enumerable collection of all pods ordered first by their port in descending order and then by their namespace in ascending order.
        public IEnumerable<Pod> GetPodsOrderedByPortThenByName()
        {
            return sortedPods.Values.OrderByDescending(p => p.Port).ThenBy(p => p.Namespace);
        }

        //This method returns the total count of all the pods that are currently deployed.
        public int Size()
        {
            return pods.Count;
        }

        //This method is used to remove a pod from the system completely. It removes any reference to the pod, effectively deleting it from the system. If there is no pod with the provided ID, it throws an ArgumentException
        public void Uninstall(string podId)
        {
            if (pods.ContainsKey(podId))
            {
                pods.Remove(podId);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        //This method is used to upgrade an existing pod. It takes a Pod object representing the updated configuration and applies it to the corresponding pod in the system. If a pod with such ID does not exist, then it's deployed.
        public void Upgrade(Pod pod)
        {
            if (pods.ContainsKey(pod.Id))
            {
                pods[pod.Id] = pod;
            }
            else
            {
                pods.Add(pod.Id, pod);
            }
        }
    }
}